/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mencoba;
import Taksonomi.Reptil;
/**
 *
 * @author lmao
 */
public class coba1 {
    public static void main(String[] args) {
        Reptil coba1 = new Reptil();
        coba1.setAlatGerak("kaki");
        coba1.setTempatHidup("dinding");
        System.out.println("coba berjalan dengan "+ coba1.getAlatGerak());
        System.out.println("ini adalah "+ coba1.getTempatHidup());
    }
}
