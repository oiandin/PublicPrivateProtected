package Taksonomi;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lmao
 */
public class MahlukHidup {
    private String AlatPernafasan;
    private String Makan;

    /**
     * @return the AlatPernafasan
     */
    public String getAlatPernafasan() {
        return AlatPernafasan;
    }

    /**
     * @return the Makan
     */
    public String getMakan() {
        return Makan;
    }

    /**
     * @param AlatPernafasan the AlatPernafasan to set
     */
    public void setAlatPernafasan(String AlatPernafasan) {
        this.AlatPernafasan = AlatPernafasan;
    }

    /**
     * @param Makan the Makan to set
     */
    public void setMakan(String Makan) {
        this.Makan = Makan;
    }
    
    
    
            
}
