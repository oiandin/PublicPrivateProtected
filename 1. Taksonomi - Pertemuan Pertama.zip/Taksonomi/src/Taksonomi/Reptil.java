package Taksonomi;


//import coba.Hewan;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

//import Hewan;

/**
 *
 * @author lmao
 */
public class Reptil extends Hewan {
    private String Darah;
    private String Makanan;
    private String RuangJantung;
    private String BagianTubuh;

    
    /**
     * @return the Darah
     */
    public String getDarah() {
        return Darah;
    }

    /**
     * @return the Makanan
     */
    public String getMakanan() {
        return Makanan;
    }

    /**
     * @return the RuangJantung
     */
    public String getRuangJantung() {
        return RuangJantung;
    }

    /**
     * @return the BagianTubuh
     */
    public String getBagianTubuh() {
        return BagianTubuh;
    }

    /**
     * @param Darah the Darah to set
     */
    public void setDarah(String Darah) {
        this.Darah = Darah;
    }

    /**
     * @param Makanan the Makanan to set
     */
    public void setMakanan(String Makanan) {
        this.Makanan = Makanan;
    }

    /**
     * @param RuangJantung the RuangJantung to set
     */
    public void setRuangJantung(String RuangJantung) {
        this.RuangJantung = RuangJantung;
    }

    /**
     * @param BagianTubuh the BagianTubuh to set
     */
    public void setBagianTubuh(String BagianTubuh) {
        this.BagianTubuh = BagianTubuh;
    }
}
