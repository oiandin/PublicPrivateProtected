package Taksonomi;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lmao
 */
public class Hewan extends MahlukHidup{
    private String AlatGerak;
    private String TempatHidup;
    private String Reproduksi;

    /**
     * @return the AlatGerak
     */
    public String getAlatGerak() {
        return AlatGerak;
    }

    /**
     * @param AlatGerak the AlatGerak to set
     */
    public void setAlatGerak(String AlatGerak) {
        this.AlatGerak = AlatGerak;
    }

    /**
     * @return the TempatHidup
     */
    public String getTempatHidup() {
        return TempatHidup;
    }

    /**
     * @param TempatHidup the TempatHidup to set
     */
    public void setTempatHidup(String TempatHidup) {
        this.TempatHidup = TempatHidup;
    }

    /**
     * @return the Reproduksi
     */
    public String getReproduksi() {
        return Reproduksi;
    }

    /**
     * @param Reproduksi the Reproduksi to set
     */
    public void setReproduksi(String Reproduksi) {
        this.Reproduksi = Reproduksi;
    }
    
}
