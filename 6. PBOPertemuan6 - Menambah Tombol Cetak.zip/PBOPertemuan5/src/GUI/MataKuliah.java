package GUI;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lmao
 */
public class MataKuliah {
    private String kodeMK;
    private String namaMK;
    private String SKS;
    private String Semester;

    /**
     * @return the kodeMK
     */
    public String getKodeMK() {
        return kodeMK;
    }

    /**
     * @param kodeMK the kodeMK to set
     */
    public void setKodeMK(String kodeMK) {
        this.kodeMK = kodeMK;
    }

    /**
     * @return the namaMK
     */
    public String getNamaMK() {
        return namaMK;
    }

    /**
     * @param namaMK the namaMK to set
     */
    public void setNamaMK(String namaMK) {
        this.namaMK = namaMK;
    }

    /**
     * @return the SKS
     */
    public String getSKS() {
        return SKS;
    }

    /**
     * @param SKS the SKS to set
     */
    public void setSKS(String SKS) {
        this.SKS = SKS;
    }

    /**
     * @return the Semester
     */
    public String getSemester() {
        return Semester;
    }

    /**
     * @param Semester the Semester to set
     */
    public void setSemester(String Semester) {
        this.Semester = Semester;
    }
           
}
